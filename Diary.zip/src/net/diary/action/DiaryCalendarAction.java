package net.diary.action;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.diary.db.DiaryDAO;
import net.member.db.MemberBean;
import net.member.db.MemberDAO;

public class DiaryCalendarAction implements Action{
	public ActionForward execute(HttpServletRequest request,HttpServletResponse response)throws Exception{
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		Calendar cal =  Calendar.getInstance();
		
		DiaryDAO diarydao = new DiaryDAO();
		
		MemberDAO memberdao = new MemberDAO();
		MemberBean memberdata = new MemberBean();
		
		List diarydata = new ArrayList();
		String year = cal.get(Calendar.YEAR)+"";
		String month = cal.get(Calendar.MONTH)+1+"";
		
		if(request.getParameter("type")!=null){
			if(request.getParameter("type").equals("1")){	//�����޺��� type�� ���������� ������������ �˷��ִ� ��
				if(request.getParameter("month").equals("12")){
					year = Integer.parseInt(request.getParameter("year"))+1+"";
					month = "1";													//12���� ��� ���⵵ 1����
				}else{
					year = request.getParameter("year");
					month = Integer.parseInt(request.getParameter("month"))+1+"";
				}
			}else if(request.getParameter("type").equals("-1")){	//�����޺���
				if(request.getParameter("month").equals("1")){
					year = Integer.parseInt(request.getParameter("year"))-1+"";	
					month = "12";													//1���� ��� ���⵵ 12����
				}else{
					year = request.getParameter("year");
					month = Integer.parseInt(request.getParameter("month"))-1+"";
					
				}
			}else if(request.getParameter("type").equals("2")){
				year = request.getParameter("year");
				month = request.getParameter("month");
			}
				
			
		}
		
		diarydata = diarydao.getCalendar(year,month,id);
		
		memberdata = memberdao.getProfile(id);
		request.setAttribute("memberdata", memberdata);
		
		if(diarydata==null){
			System.out.println("�޷º��� ����");
			return null;
		}
		System.out.println("�޷º��� ����");
		request.setAttribute("year", year);
		request.setAttribute("month", month);
		
		request.setAttribute("diarydata",diarydata);
		ActionForward forward=new ActionForward();
		forward.setRedirect(false);
		forward.setPath("./diarycalendar.jsp");
		return forward;
	}
}
