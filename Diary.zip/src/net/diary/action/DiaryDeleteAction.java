package net.diary.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.exam.FileDeleteServlet;

import net.diary.db.DiaryBean;
import net.diary.db.DiaryDAO;

public class DiaryDeleteAction implements Action{
	public String toKr(String value){
		String result= null;
		try{
			result = new String(value.getBytes("8859_1"), "utf-8");	//8859_1�������� �о�鿩�� utf-8�������� ��ȯ
		}catch(Exception e){}
		return result;
	}
	public ActionForward execute(HttpServletRequest request,HttpServletResponse response)throws Exception{
		
		ActionForward forward=new ActionForward();

		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		boolean result=false;
		boolean usercheck=false;
		int num=Integer.parseInt(request.getParameter("num"));
		
		DiaryBean diarydata = new DiaryBean();
		DiaryDAO diarydao=new DiaryDAO();
		usercheck=diarydao.isDiaryWriter(num, id);
		
		if(usercheck==false){
			response.setContentType("text/html;charset=utf-8");
			forward.setRedirect(false);
			forward.setPath("./DiaryShareDetailAction.di?num="+num);
			
			return forward;
		}
//		diarydata = diarydao.getDetail(num);
//		String filename = diarydata.getDiary_file();
//		FileDeleteServlet.processDeleteFile(filename); 
		result=diarydao.diaryDelete(num);			//���� �����ϴ� �κ�
		if(result==false){
			System.out.println("�Խ��� ���� ����");
			return null;
		}
		System.out.println("�Խ��� ���� ����");
		forward.setRedirect(true);
		forward.setPath("./DiaryListAction.di");
		return forward;
	}
}
