package net.diary.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.member.action.MemberFindFriendAction;


public class DiaryFrontController extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet{

	private static final long serialVersionUID = 1L;
	protected void doProcess(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		request.setCharacterEncoding("utf-8");
		String RequestURI=request.getRequestURI();
		String contextPath=request.getContextPath();
		String command=RequestURI.substring(contextPath.length());
		ActionForward forward=null;
		Action action=null;
		
		if(command.equals("/DiaryWrite.di")){
			forward=new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./diarywrite.jsp");
		}else if(command.equals("/DiaryShareWrite.di")){
				forward=new ActionForward();
				forward.setRedirect(false);
				forward.setPath("./diarysharewrite.jsp");	
		}else if(command.equals("/DiaryShareAdd.di")){
			forward=new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./diaryshareadd.jsp");	
		}else if(command.equals("/ShowMapAction.di")){
			forward=new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./showmap.jsp");	
		}
		else if(command.equals("/DiaryModify.di")){
			action=new DiaryModifyView();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}
		}else if(command.equals("/DiaryShareModify.di")){
			action=new DiaryShareModifyView();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}	
		}else if(command.equals("/DiaryWriteAction.di")){
			action=new DiaryWriteAction();
			try{
				forward=action.execute(request,response);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}else if(command.equals("/DiaryModifyAction.di")){
			action=new DiaryModifyAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}
		}else if(command.equals("/DiaryShareModifyAction.di")){
			action=new DiaryShareModifyAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}	
		}else if(command.equals("/DiaryDeleteAction.di")){
			action=new DiaryDeleteAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}
		}else if(command.equals("/DiaryListAction.di")){
			action=new DiaryListAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}
		}else if(command.equals("/DiaryDetailAction.di")){
			action=new DiaryDetailAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}
		}else if(command.equals("/DiaryMenuDetailAction.di")){
			action=new DiaryMenuDetailAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}
		}else if(command.equals("/DiaryCalendarAction.di")){
			action=new DiaryCalendarAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}
		}else if(command.equals("/DiaryShareAddAction.di")){
			action=new DiaryShareAddAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}
		}else if(command.equals("/DiaryShareDetailAction.di")){
			action=new DiaryShareDetailAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}
		}else if(command.equals("/DiaryShareListAction.di")){
			action=new DiaryShareListAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		if(forward!=null){
			if(forward.isRedirect()){
				response.sendRedirect(forward.getPath());
			}else{
				RequestDispatcher dispatcher=
						request.getRequestDispatcher(forward.getPath());
				dispatcher.forward(request, response);
			}
		}
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException{
		this.doProcess(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		this.doProcess(request, response);
	}
	

}