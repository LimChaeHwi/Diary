package net.diary.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.diary.db.DiaryDAO;
import net.member.db.MemberBean;
import net.member.db.MemberDAO;

public class DiaryMenuDetailAction implements Action{
	public ActionForward execute(HttpServletRequest request,HttpServletResponse response)throws Exception{
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		String diary_type = (String)request.getParameter("diary_type");
		DiaryDAO diarydao=new DiaryDAO();
		MemberDAO memberdao = new MemberDAO();
		MemberBean memberdata = new MemberBean();
		List diarylist=new ArrayList();
				
		int listcount=diarydao.getMenuDetailCount(id,diary_type);	//�� ����Ʈ ���� �޾ƿ�
		diarylist=diarydao.getDiaryMenuDetail(id,diary_type);		//����Ʈ�� �޾ƿ�

		request.setAttribute("listcount", listcount);		//�� ��
		request.setAttribute("diarylist", diarylist);		//���̾ ����Ʈ
															//request��ü�� ���
		memberdata = memberdao.getProfile(id);
		request.setAttribute("memberdata", memberdata);
		
		ActionForward forward=new ActionForward();
		forward.setRedirect(false);
		forward.setPath("./diarymenulist.jsp");
		return forward;
	}
}
