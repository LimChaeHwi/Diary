package net.diary.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.diary.db.DiaryBean;
import net.diary.db.DiaryDAO;

public class DiaryShareModifyView implements Action{
	
	public ActionForward execute(HttpServletRequest request,HttpServletResponse response)throws Exception{
		
		ActionForward forward=new ActionForward();
		request.setCharacterEncoding("utf-8");
		
		DiaryDAO diarydao=new DiaryDAO();
		DiaryBean diarydata=new DiaryBean();
		
		int num=Integer.parseInt(request.getParameter("num"));
		diarydata=diarydao.getDetail(num);
		
		if(diarydata==null){
			System.out.println("(����)�󼼺��� ����");
			return null;
		}
		System.out.println("(����)�󼼺��� ����");
		
		request.setAttribute("diarydata", diarydata);
		
		forward.setRedirect(false);
		forward.setPath("./diarysharemodify.jsp");
		return forward;
	}

}
