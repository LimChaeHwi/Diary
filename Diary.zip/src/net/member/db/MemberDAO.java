package net.member.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.json.simple.JSONObject;

import net.diary.db.DiaryBean;

public class MemberDAO {
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	DataSource ds;
	
	public  MemberDAO(){	//�����ڿ��� �����ͼҽ��� ����.
		try{
			Context init = new InitialContext();						 //Context�� ��ü�� ����
			ds = (DataSource)init.lookup("java:comp/env/jdbc/OracleDB"); //lookup�� �̿��ؼ� DataSource�� ����
		}catch(Exception ex){
			System.out.println("DB���� ����:"+ex);
			return;
		}
	}
	public void close(ResultSet rs, PreparedStatement pstmt, Connection con){
		if(rs!=null)try{rs.close();}catch(SQLException ex){}
		if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}
		if(con!=null)try{con.close();}catch(SQLException ex){}
	}
	//�α���
	public int isMember(MemberBean memberdata){					
		String sql="select password, name from diarymember where id=?";
		int result = -1;
		try{
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberdata.getId());
			rs = pstmt.executeQuery();
			
			if(rs.next()){
					if(rs.getString("password").equals(memberdata.getPassword())){
						result = 1; //��й�ȣ ��ġ
						memberdata.setName(rs.getString("name"));			//�̸� �ҷ��ͼ� ����
					}else{
						result = 0; //��й�ȣ ����ġ
					}	
			}else{
					result = -1; //�������� ���� ���̵�
			}
			}catch(Exception ex){
				System.out.println("isMember����:"+ex);
			}finally{
				close(rs,pstmt,con);
			}
			return result;
	}
	//ȸ������
	public boolean joinMember(MemberBean memberdata){
		String sql = "insert into diarymember(id, password, name, gender, birthday, blood, phone,"
				+" address, email, joindate) values(?,?,?,?,?,?,?,?,?,?)";
		int result = 0;
		
		try{
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberdata.getId());
			pstmt.setString(2, memberdata.getPassword());
			pstmt.setString(3, memberdata.getName());
			pstmt.setString(4, memberdata.getGender());
			pstmt.setString(5, memberdata.getBirthday());
			pstmt.setString(6, memberdata.getBlood());
			pstmt.setString(7, memberdata.getPhone());
			pstmt.setString(8, memberdata.getAddress());
			pstmt.setString(9, memberdata.getEmail());
			pstmt.setTimestamp(10, memberdata.getJoindate());
			result = pstmt.executeUpdate();
			
				if(result!=0){
					return true;
				}
			}catch(Exception ex){
				System.out.println("joinMember����:"+ex);
			}finally{
				close(rs, pstmt, con);
			}
			return false;
	}
	//�������̾���� ���̵�� ģ�� ã��
	public String getFindFriend(String friend_id){
		
		String find_friend_sql = "select name from diarymember where id=?";
		String result = null;
		try
		{	
			con = ds.getConnection();
			pstmt=con.prepareStatement(find_friend_sql);
			pstmt.setString(1, friend_id);
			rs=pstmt.executeQuery();
			if(rs.next()){
					result = rs.getString("name"); //��й�ȣ ��ġ
			}else{ 
					result = null; //�������� ���� ���̵�
					System.out.println("�������� �ʴ� ���̵�");
			} 
			return result;
		}
		catch(Exception ex)
		{
			System.out.println("getFindFriend ����:"+ex);
		}
		finally
		{
			close(rs,pstmt,con);
		}
		return result;
	}
	//�н��� ���̵� ã��
	public String getFindId(String name, String birthday){
		
		String find_id_sql = "select id from diarymember where name=? and birthday=?";
		String result = null;
		try
		{	
			con = ds.getConnection();
			pstmt=con.prepareStatement(find_id_sql);
			pstmt.setString(1, name);
			pstmt.setString(2, birthday);
			rs=pstmt.executeQuery();
			if(rs.next()){
					result = rs.getString("id"); //�̸� ������� ��ġ
					
			}else{ 
					result = null; //�������� ���� ���̵�
					System.out.println("�������� �ʴ� ���̵�");
			} 
			return result;
		}
		catch(Exception ex)
		{
			System.out.println("getFindId ����:"+ex);
		}
		finally
		{
			close(rs,pstmt,con);
		}
		return result;
	}
	//�н��� ��й�ȣ ã��
	public String getFindPassword(String id, String name, String birthday){
		
		String find_password_sql = "select password from diarymember where id=? and name=? and birthday=?";
		String result = null;
		try
		{	
			con = ds.getConnection();
			pstmt=con.prepareStatement(find_password_sql);
			pstmt.setString(1, id);
			pstmt.setString(2, name);
			pstmt.setString(3, birthday);
			rs=pstmt.executeQuery();
			if(rs.next()){
					result = rs.getString("password"); //���̵� �̸� ������� ��ġ
					
			}else{ 
					result = null; //�������� ���� ���̵�
					System.out.println("�������� �ʴ� ���̵�");
			} 
			return result;
		}
		catch(Exception ex)
		{
			System.out.println("getFindPassword ����:"+ex);
		}
		finally
		{
			close(rs,pstmt,con);
		}
		return result;
	}
	//���̵� �ߺ�Ȯ��
	public int getDoubleCheck(String id){					
		String sql="select id from diarymember where id=?";
		int result = 0;
		try{
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if(rs.next()){
					result = 1;	//���̵� �ߺ�
			}else{
					result = 0; //��밡���� ���̵�
			}
			System.out.println(result);
		}
		catch(Exception ex){
				System.out.println("getDoubleCheck����:"+ex);
			}finally{
				close(rs,pstmt,con);
			}
		
			return result;
	}
	//ȸ������ ��������
	public MemberBean getProfile(String id)throws Exception{
		MemberBean memberdata=null;
		try
		{
			con = ds.getConnection();
			pstmt=con.prepareStatement("select *from diarymember where id=?");
			pstmt.setString(1, id);
			
			rs=pstmt.executeQuery();
			
			if(rs.next())
			{
				memberdata=new MemberBean();
				
				memberdata.setImage(rs.getString("image"));
				memberdata.setId(rs.getString("id"));
				memberdata.setName(rs.getString("name"));
				memberdata.setGender(rs.getString("gender"));
				memberdata.setBirthday(rs.getString("birthday"));
				memberdata.setBlood(rs.getString("blood"));
				memberdata.setPhone(rs.getString("phone"));
				memberdata.setAddress(rs.getString("address"));
				memberdata.setEmail(rs.getString("email"));
			}
			return memberdata;
		}
		catch(Exception ex)
		{
			System.out.println("getProfile ����:"+ex);
		}
		finally
		{
			close(rs,pstmt,con);
		}
		return null;
	}
	//ȸ������ �����ϱ�
	public boolean memberModify(MemberBean memberdata)throws Exception{
		String sql="update diarymember set password=?, name=?, gender=?, birthday=?"+
				", blood=?, phone=?, address=?, email=?, image=? where id=?";
		try
		{
			con = ds.getConnection();
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, memberdata.getPassword());
			pstmt.setString(2, memberdata.getName());
			pstmt.setString(3, memberdata.getGender());
			pstmt.setString(4, memberdata.getBirthday());
			pstmt.setString(5, memberdata.getBlood());
			pstmt.setString(6, memberdata.getPhone());
			pstmt.setString(7, memberdata.getAddress());
			pstmt.setString(8, memberdata.getEmail());
			pstmt.setString(9, memberdata.getImage());
			pstmt.setString(10, memberdata.getId());
			
			
			pstmt.executeUpdate();
			
			return true;
		}
		catch(Exception ex){
			System.out.println("memberModify ����:"+ex);
		}
		finally
		{
			close(rs,pstmt,con);
		}
		return false;
	}
	//ȸ��Ż���ϱ�
	public boolean memberDelete(String id)throws Exception{
		String sql ="delete from diarymember where id=?";
		
		try{
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			
			pstmt.executeUpdate();
			return true;
		}catch(Exception ex){
			System.out.println("memberDelete ����:"+ex);
		}
		finally
		{
			close(rs,pstmt,con);
		}
		return false;
	}
}

