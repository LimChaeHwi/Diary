package net.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.member.action.ActionForward;
import net.member.db.MemberBean;
import net.member.db.MemberDAO;

public class MemberModify implements Action{
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)throws Exception{
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		String id=(String)session.getAttribute("id");
		MemberDAO memberdao=new MemberDAO();
		MemberBean memberdata=new MemberBean(); 
		
		memberdata=memberdao.getProfile(id);
		
		if(memberdata==null){
			System.out.println("ȸ���������� ����");
			return null;
		}
		System.out.println("ȸ���������� ����");
		
		request.setAttribute("memberdata",memberdata);
		
		ActionForward forward=new ActionForward();
		forward.setRedirect(false);
		forward.setPath("./memberinfo.jsp");
		return forward;
	}
}
