package net.member.action;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONObject;

import net.member.db.MemberDAO;

public class MemberDoubleCheckAction implements Action{
	public ActionForward execute(HttpServletRequest request,HttpServletResponse response)throws Exception{
		
		String sid = request.getParameter("sid");
		
		MemberDAO memberdao=new MemberDAO();
		int result = 0;
		result = memberdao.getDoubleCheck(sid);		//�ߺ��Ǵ� ���̵� �ִ��� Ȯ��
//		request.setAttribute("result", result);
//		PrintWriter pw = null;		
//		pw = response.getWriter();

//		pw.print("<?xml version=\'1.0\' encoding=\'UTF-8\'?>");
//		pw.print("<data>");
//		pw.print("<result>"+check+"</result>");
//		pw.print("</data>");
//		pw.flush();
//		pw.close();
		
/*		PrintWriter out = response.getWriter();
		System.out.println(check);
		if(check){
			out.print("{result : success}");
		}else{
			out.print("{result : fail}");
		}*/
		JSONObject obj = new JSONObject();
		
		if(result==0){
			obj.put("result", 0);	//��� ���� 0��
		}else{
			obj.put("result", 1);
		}
//		try{
//			response.setCharacterEncoding("utf-8");
//			response.getWriter().print(obj.toString());
//		}catch(IOException e){
//			e.printStackTrace();
//		}
		ActionForward forward=new ActionForward();
		forward.setRedirect(false);
		forward.setPath("./joinform.me");
		
		return forward;
	}
}
