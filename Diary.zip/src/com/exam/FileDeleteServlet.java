package com.exam;

import java.io.File;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import org.apache.commons.fileupload.FileItem;

@WebServlet("/FileDeleteServlet") 
public class FileDeleteServlet extends HttpServlet{
	private static final long serialVersionUID = 2L;

	//���� ó��
	public static void processDeleteFile(String filename) throws Exception {
		String contextRootPath = "C:/Bigdata/html/.metadata/.plugins/org.eclipse.wst.server.core/tmp1/wtpwebapps/Diary";	//������ ���� ���
		String fileName = filename; 				//���ϸ� ���
		StringTokenizer stok = new StringTokenizer(fileName,"/");
		while(stok.hasMoreTokens()){
	//		FileItem token = stok.nextToken();
		List<FileItem> items;
//		items.add(token);
//		for(FileItem item : items){
		//������ ���� ��η� ���� ��ü ����
		File deleteImg = new File(contextRootPath + "/upload/" + fileName); 
		File deleteThumbImg = new File(contextRootPath + "/thumbnail/" + fileName);
//		item.delete(); 
		}
	}

}

